#include "bktpool.h"

int bktpool_init()
{
   return bkwrk_create_worker();
} 
